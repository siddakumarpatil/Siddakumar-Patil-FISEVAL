package com.example.trip.trip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripApplicationTests {

	@Test
	void contextLoads() {
	}

}
