package com.example.servicecar;

import org.apache.catalina.User;
import org.springframework.boot.SpringApplication;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.servicecar.entity.*;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@RestController
@CrossOrigin(origin="*")
public class ServicecarApplication {

	@Autowired
	private UserRepository repository;
	
	@PostMapping("/register")
	public string registe(@RequestBody User user) {
		repository.save(user);
		return "Hi"+user.getName()+"Registered Successsflly";
	}
	
	@PostMapping("/getAllUsers")
	public List<User> findAllUser() {
		
		return repository.findAll();
	}
	
	@PostMapping("/findUser/{email}")
	public List<User> findUser(@PathVariable String email) {
		return repository.findByEmail(email);
	}
	
	@PostMapping("/cancel/{id}")
	public List<User> cancelRegisteration(@PathVariable int id) {
		repository.deleteById(id);
		return repository.findAll();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(ServicecarApplication.class, args);
	}
	

}
