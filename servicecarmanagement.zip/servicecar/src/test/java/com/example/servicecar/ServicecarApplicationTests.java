package com.example.servicecar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicecarApplicationTests {

	@Test
	void contextLoads() {
	}

}
